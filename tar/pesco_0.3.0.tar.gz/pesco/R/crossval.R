## cycling over stations: kriging whitout a station


## cross validation


## skill scores


